# GestionCamping
Laboratorio interacción persona ordenador (IPO) [2020-2021]
